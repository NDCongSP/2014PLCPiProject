sleep 15;
lxterminal --command "sudo wvdial"