sleep 15s
sudo epiphany-browser http://192.168.1.113:8080/