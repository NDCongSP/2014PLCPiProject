sleep 10s

sudo epiphany-browser http://192.168.1.37:7000/Hienthi.aspx