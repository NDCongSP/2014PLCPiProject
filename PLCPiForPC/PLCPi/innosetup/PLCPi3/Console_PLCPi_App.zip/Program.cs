﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using PLCPiProject;
 
namespace $safeprojectname$
{
    class Program
    {
        //Khoi tao doi tuong myPLC
        static PLCPi myPLC = new PLCPi(); 
        static void Main(string[] args)
        {
        }
    }
}
