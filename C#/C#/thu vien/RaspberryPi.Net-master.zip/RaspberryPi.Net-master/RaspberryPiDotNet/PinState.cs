﻿namespace RaspberryPiDotNet
{
    /// <summary>
    /// This is a cleaner way to write the Pin Status
    /// </summary>
    public enum PinState
    {
        High,
        Low
    }
}