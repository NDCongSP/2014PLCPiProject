﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RaspberryPiDotNet
{
    public enum GPIOResistor
    {
        OFF = 0,
        PULL_DOWN = 1,
        PULL_UP = 2
    }
}
