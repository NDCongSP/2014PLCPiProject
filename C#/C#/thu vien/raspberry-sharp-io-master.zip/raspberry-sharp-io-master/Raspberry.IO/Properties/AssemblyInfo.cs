﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Raspberry.IO")]
[assembly: AssemblyDescription("Raspberry Pi IO Components")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("cdb59592-d7c3-450e-ad8a-f02902e2ea51")]
