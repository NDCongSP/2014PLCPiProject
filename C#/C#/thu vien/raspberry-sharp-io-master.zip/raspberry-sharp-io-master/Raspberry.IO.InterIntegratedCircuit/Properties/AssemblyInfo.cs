﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Raspberry.IO.InterIntegratedCircuit")]
[assembly: AssemblyDescription("Raspberry Pi I2C Mono Library")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c0ac7c73-677d-42b4-9338-9138fbf95d10")]
