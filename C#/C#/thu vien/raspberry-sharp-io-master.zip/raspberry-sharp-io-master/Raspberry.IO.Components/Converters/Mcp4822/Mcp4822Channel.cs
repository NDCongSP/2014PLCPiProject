namespace Raspberry.IO.Components.Converters.Mcp4822
{
    public enum Mcp4822Channel
    {
        ChannelA = 0,
        ChannelB = 1
    }
}