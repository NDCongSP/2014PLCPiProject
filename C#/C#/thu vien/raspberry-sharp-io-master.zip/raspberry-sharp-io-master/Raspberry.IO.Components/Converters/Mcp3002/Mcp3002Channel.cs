namespace Raspberry.IO.Components.Converters.Mcp3002
{
    public enum Mcp3002Channel
    {
        Channel0 = 0,
        Channel1 = 1
    }
}