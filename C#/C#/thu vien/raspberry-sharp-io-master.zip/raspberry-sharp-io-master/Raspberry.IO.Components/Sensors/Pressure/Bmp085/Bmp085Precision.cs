﻿namespace Raspberry.IO.Components.Sensors.Pressure.Bmp085
{
    public enum Bmp085Precision
    {
        Low = 0,
        Standard = 1,
        High = 2,
        Highest = 3
    }
}