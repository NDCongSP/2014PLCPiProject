﻿namespace Raspberry.IO.Components.Controllers.Pca9685
{
    /// <summary>
    /// Denotes available PWM channels
    /// </summary>
    public enum PwmChannel
    {
        C0 = 0,
        C1 = 1,
        C2 = 2,
        C3 = 3,
        C4 = 4,
        C5 = 5,
        C6 = 6,
        C7 = 7,
        C8 = 8,
        C9 = 9,
        C10 = 10,
        C11 = 11,
    }
}