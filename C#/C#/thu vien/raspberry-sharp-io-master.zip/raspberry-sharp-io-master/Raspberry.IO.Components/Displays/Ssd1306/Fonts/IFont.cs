using System;

namespace Raspberry.IO.Components.Displays.Ssd1306.Fonts
{
    public interface IFont
    {
        byte[][] GetData();
    }
}

