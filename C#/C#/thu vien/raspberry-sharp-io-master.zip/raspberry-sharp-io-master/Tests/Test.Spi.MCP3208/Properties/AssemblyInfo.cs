﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Test.Spi.MCP3208")]
[assembly: AssemblyDescription("Raspberry Pi MCP3208 Component Sample")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("2e0267cc-028e-4e7a-8ca6-d9cab73f13ed")]

