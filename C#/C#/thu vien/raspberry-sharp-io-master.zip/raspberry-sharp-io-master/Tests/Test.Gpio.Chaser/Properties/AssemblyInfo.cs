﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Test.Gpio.Chaser")]
[assembly: AssemblyDescription("Raspberry Pi Chaser GPIO Sample")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("80b17b2e-8eac-429c-a817-6c770a44c466")]
