# Snap7

This is a fork of http://snap7.sourceforge.net/

Current Goal: Make the server work with TIA Portal to handle up- and downloads.